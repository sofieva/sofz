Frontend code for Mshel Homes Asset Management System built using JavaScript.

# Training on git branch