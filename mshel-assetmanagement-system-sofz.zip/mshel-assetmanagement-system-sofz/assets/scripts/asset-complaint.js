// Expand and shrink navbar
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.getElementById('main-content');
    const toggleIcon = document.getElementById('toggle-icon');

    sidebar.classList.toggle('sidebar-is-reduced');
    sidebar.classList.toggle('sidebar-is-expanded');
    mainContent.classList.toggle('content-is-expanded');

    // Rotate the icon when sidebar is expanded
    toggleIcon.classList.toggle('fa-angle-left');
    toggleIcon.classList.toggle('fa-angle-right');
}

// Submenu dropdown
document.addEventListener('DOMContentLoaded', function () {
    const menuItems = document.querySelectorAll('.s-menu_item.has-submenu');

    menuItems.forEach(item => {
        const submenu = item.querySelector('.s-menu_submenu');

        item.addEventListener('click', function (e) {
            // Prevent parent menu item from triggering
            if (!e.target.closest('.s-menu_item_inner')) return;

            // Close all open submenus except the clicked one
            menuItems.forEach(i => {
                if (i !== item) {
                    i.classList.remove('is-active');
                    const openSubmenu = i.querySelector('.s-menu_submenu');
                    if (openSubmenu) {
                        openSubmenu.style.maxHeight = null;
                    }
                }
            });

            // Toggle the clicked item
            item.classList.toggle('is-active');

            // Animate submenu open/close
            if (submenu) {
                if (submenu.style.maxHeight) {
                    submenu.style.maxHeight = null;
                } else {
                    submenu.style.maxHeight = submenu.scrollHeight + "px";
                }
            }
        });
    });
});


