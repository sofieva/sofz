document.getElementById('form').addEventListener('submit', async function (event) {
    event.preventDefault();

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    const formData = new FormData();
    formData.append('email', email);
    formData.append('password', password);

    try {
        const response = await fetch('https://assets-api.mshelhomes.com/api/login', {
            method: 'POST',
            headers: {
                'Accept': 'application/vnd.api+json',
            },
            body: formData
        });

        if (response.ok) {
            const data = await response.json();
            console.log('Login successful:', data);
            // Store the token in localStorage
            localStorage.setItem('authToken', data.token);
            alert('Login successful');
            window.location.href = './pages/user/asset-registration-form.html';
        } else {
            const errorData = await response.json();
            console.error('Login failed:', errorData);
            alert('Login failed: ' + errorData.message); // Display the error message to the user
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred. Please try again.');
    }
});
